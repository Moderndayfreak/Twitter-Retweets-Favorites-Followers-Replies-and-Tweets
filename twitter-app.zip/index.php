<!DOCTYPE html>

<html class="" lang="en" style="background-color: #1b252e;">
<head>
	<meta charset="utf-8">

	<title>Select your service.</title>
	<meta content=
	"app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav"
	name="description">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1" name=
	"viewport">
	<link href="css/app.v2.css" rel="stylesheet" type="text/css">
	<link cache="false" href="css/font.css" rel="stylesheet" type="text/css">
	<link cache="false" href="css/landing.css" rel="stylesheet" type=
	"text/css"><!--[if lt IE 9]> <script src="js/ie/html5shiv.js" cache="false"></script> <script src="js/ie/respond.min.js" cache="false"></script> <script src="js/ie/excanvas.js" cache="false"></script> <![endif]-->
	</head>

<body>
	<footer id="footer">
		<div class="bg-dark dker wrapper">
			<div class="container text-center m-t-lg">
				<div class="m-t-xl m-b-xl">
					<span class="xx">
						<span class="a"><a style="width:100px;" class="btn btn-icon btn-rounded btn-twitter bg-empty m-sm" data-title="Twitter" href="twitter.php" data-toggle="tooltip" data-placement="left" title="" data-original-title="Twitter Services"><i class="fa fa-twitter"></i></a></span>
						<span class="f"><a style="width:100px;" class="btn btn-icon btn-rounded btn-gplus bg-empty m-sm" data-title="Snapchat" href="signin.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Snapchat Services"><i class="fa fa-trophy"></i></a></span>
					</span>
				</div>
				
				<div>
					<span style="font-size:20px; font-variant:small-caps;">
					select a service.
					</span>
				</div>
			</div>
		</div>
	</footer><!-- / footer --><script src="js/app.v2.js"></script><!-- Bootstrap --><!-- App --><script src=
"js/appear/jquery.appear.js"></script><script src="js/scroll/smoothscroll.js"></script><script src="js/landing.js"></script>
</body>
</html> 
