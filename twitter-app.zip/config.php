<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', '');
define('CONSUMER_SECRET', '');
define('OAUTH_CALLBACK', 'http://iamusicent.com/callback.php');
define('DB_HOST', '');
define('DB_USER', '');
define('DB_PASS', '');
define('DB_DB', 'twtid');